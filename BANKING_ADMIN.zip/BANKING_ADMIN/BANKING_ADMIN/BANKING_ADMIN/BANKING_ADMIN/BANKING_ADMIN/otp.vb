﻿Imports System.Net.Mail
Imports System.Data.SqlClient

Public Class otp

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        uname = LoginForm1.UsernameTextBox.Text
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        'MsgBox("select * from userlogin where otp='" & TextBox1.Text & "'")
        Dim cmd0 As New SqlCommand("select * from userlogin where otp='" & TextBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader()
        If d1.HasRows Then
            MsgBox("OTP Verified")
            rfidverify.Show()
            LoginForm1.Close()


        Else
            MsgBox("Invalid Otp")
        End If




    End Sub

    Private Sub otp_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Textbox1.Focus()
    End Sub

    Private Sub Panel1_Paint(sender As System.Object, e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class