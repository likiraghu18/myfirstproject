﻿Imports System.Data.SqlClient

Public Class sbbalance

    Private Sub sbbalance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        TextBox1.Enabled = False
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("Select Sbaccno From Sbcustentry order by Sbaccno", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        While d1.Read()
            ComboBox1.Items.Add(d1(0).ToString)
        End While
    End Sub





    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select Sbaccno from sbcustentry where Sbaccno='" & ComboBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            d1.Read()
            ComboBox1.Text = d1(0).ToString
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim t1, t2 As Double
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim Cmd0 As New SqlCommand("select sum(Amount) from sbdepentry where [SB A/c No]='" & ComboBox1.Text & "'", conn)
        Dim D1 As SqlDataReader = Cmd0.ExecuteReader()
        If D1.HasRows Then
            D1.Read()
            t1 = IIf(IsDBNull(D1(0)), 0, D1(0))
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim Cmd1 As New SqlCommand("select sum(Amount) from sbwithdrawentry where [SB A/c No]='" & ComboBox1.Text & "'", conn)
        Dim D2 As SqlDataReader = Cmd1.ExecuteReader()
        If D2.HasRows Then
            D2.Read()
            t2 = IIf(IsDBNull(D2(0)), 0, D2(0))
        End If
        TextBox1.Text = "₹" & t1 - t2
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    
End Class