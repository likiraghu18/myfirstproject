﻿Imports System.Windows.Forms

Public Class MDIParent1

    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs)
        ' Create a new instance of the child form.
        Dim ChildForm As New System.Windows.Forms.Form
        ' Make it a child of this MDI form before showing it.
        ChildForm.MdiParent = Me

        m_ChildFormNumber += 1
        ChildForm.Text = "Window " & m_ChildFormNumber

        ChildForm.Show()
    End Sub

    Private Sub OpenFile(ByVal sender As Object, ByVal e As EventArgs)
        Dim OpenFileDialog As New OpenFileDialog
        OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        OpenFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        If (OpenFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = OpenFileDialog.FileName
            ' TODO: Add code here to open the file.
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim SaveFileDialog As New SaveFileDialog
        SaveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"

        If (SaveFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = SaveFileDialog.FileName
            ' TODO: Add code here to save the current contents of the form to a file.
        End If
    End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.Close()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        'Use My.Computer.Clipboard.GetText() or My.Computer.Clipboard.GetData to retrieve information from the clipboard.
    End Sub


    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub TileVerticalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub TileHorizontalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub ArrangeIconsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private m_ChildFormNumber As Integer

  
    Private Sub SavingBankAcTypesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SavingBankAcTypesToolStripMenuItem.Click
        Sbacctypeform.MdiParent = Me
        Sbacctypeform.Show()
    End Sub

    Private Sub SBCustomerEntryToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SBCustomerEntryToolStripMenuItem.Click
        Sbcustform.MdiParent = Me
        Sbcustform.Show()
    End Sub

    Private Sub AmountDepositToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AmountDepositToolStripMenuItem.Click
        SBdepform.MdiParent = Me
        SBdepform.Show()
    End Sub

    Private Sub AmountWithdrawToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AmountWithdrawToolStripMenuItem.Click
        sbwithdrawform.MdiParent = Me
        sbwithdrawform.Show()
    End Sub

    Private Sub MDIParent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        otp.Close()
        rfidverify.Close()
        LoginForm1.Close()
        Me.WindowState = FormWindowState.Maximized
        dat.Text = Date.Now.ToString("dd/MMM/yyyy")
    End Sub

    Private Sub CurrentAccountTypesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CurrentAccountTypesToolStripMenuItem.Click
        Cacctypeform.MdiParent = Me
        Cacctypeform.Show()
    End Sub

    Private Sub CurrentAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CurrentAccountToolStripMenuItem.Click

    End Sub

    Private Sub CACustomerEntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CACustomerEntryToolStripMenuItem.Click
        Ccustform.MdiParent = Me
        Ccustform.Show()
    End Sub

    Private Sub CADepositEntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CADepositEntryToolStripMenuItem.Click
        cadepform.MdiParent = Me
        cadepform.Show()
    End Sub

    Private Sub CAWithdrawEntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CAWithdrawEntryToolStripMenuItem.Click
        Cawithdrawform.MdiParent = Me
        Cawithdrawform.Show()
    End Sub

    Private Sub SBCustomerListToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SBCustomerListToolStripMenuItem.Click
        Sbcustlist.MdiParent = Me
        Sbcustlist.Show()
    End Sub

    Private Sub SBDepositListToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SBDepositListToolStripMenuItem.Click
        Sbdepositlist.MdiParent = Me
        Sbdepositlist.Show()
    End Sub

    Private Sub SbWithdrawListToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SbWithdrawListToolStripMenuItem.Click
        Sbwithdrawlist.MdiParent = Me
        Sbwithdrawlist.Show()
    End Sub

    Private Sub CustomerListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerListToolStripMenuItem.Click
        CAcustlist.MdiParent = Me
        CAcustlist.Show()
    End Sub

    Private Sub CADepositListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CADepositListToolStripMenuItem.Click
        CAdeplist.MdiParent = Me
        CAdeplist.Show()
    End Sub

    Private Sub CAWithdrawListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CAWithdrawListToolStripMenuItem.Click
        CAwithdralist.MdiParent = Me
        CAwithdralist.Show()
    End Sub

    Private Sub SavingsAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SavingsAccountToolStripMenuItem.Click
        sbbalance.MdiParent = Me
        sbbalance.Show()
    End Sub

    Private Sub CurrentAccountToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CurrentAccountToolStripMenuItem1.Click
        cabalance.MdiParent = Me
        cabalance.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles LogoutToolStripMenuItem.Click
        If MessageBox.Show("Are you sure you want to Logout ?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            LoginForm1.Show()
            Me.Close()
        Else
            Me.Show()
        End If

    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles HomeToolStripMenuItem.Click
        Sbacctypeform.Close()
        Sbcustform.Close()
        SBdepform.Close()
        sbwithdrawform.Close()
        Cacctypeform.Close()
        Ccustform.Close()
        cadepform.Close()
        Cawithdrawform.Close()
        Sbcustlist.Close()
        Sbdepositlist.Close()
        Sbwithdrawlist.Close()
        CAcustlist.Close()
        CAdeplist.Close()
        CAwithdralist.Close()
        sbbalance.Close()
        cabalance.Close()

    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        time.Text = TimeOfDay
    End Sub
End Class
