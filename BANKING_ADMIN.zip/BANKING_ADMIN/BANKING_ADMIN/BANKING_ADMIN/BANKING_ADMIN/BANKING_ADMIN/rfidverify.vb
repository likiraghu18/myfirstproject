﻿Imports System.Data.SqlClient

Public Class rfidverify
    'Dim a As String
    'Dim b As String
    Dim username As String
    Dim myPort As Array
    Delegate Sub SetTextCallback(ByVal [text] As String) 'Added to prevent threading errors during receiveing of data

    Private Sub SerialPort1_DataReceived(ByVal sender As System.Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived

        ReceivedText(SerialPort1.ReadExisting())

    End Sub

    Private Sub ReceivedText(ByVal [text] As String) 'input from ReadExisting

        If Me.TextBox1.InvokeRequired Then
            Dim x As New SetTextCallback(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.TextBox1.Text = [text] 'append text
        End If
    End Sub

    Private Sub rfidverify_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TextBox1.Text = 123456
        Button1.Focus()
        SerialPort1.PortName = "COM6"
        SerialPort1.BaudRate = "9600"
        SerialPort1.Open()
        username = LoginForm1.UsernameTextBox.Text
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from userlogin where username='" & username & "'and rfid='" & TextBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader()
        If d1.HasRows Then
            MsgBox("Access Granted!!")
            MDIParent1.Show()
        Else
            MsgBox("Access Denied")
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
    End Sub
End Class