﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Public Class Ccustform
    Dim pkvar As String
    Dim RandGen As New Random
    Dim a As String
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
        a = RandGen.Next(101, 200).ToString
        TextBox1.Text = "CA25330" + a
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        saverecord()
    End Sub
    Sub saverecord()
        If TextBox1.Text = "" Then
            MsgBox("Please enter the account number")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("Please enter name")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("Please enter the address")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("Please enter the pincode")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("Please enter the phone no.")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("Please enter email")
            Exit Sub
        End If
        If ComboBox1.Text = "" Then
            MsgBox("Please select any gender")
            Exit Sub
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from Ccustentry where Caccno='" & TextBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            MsgBox("Record is already present")
            Exit Sub
        End If
        Dim q1var, q2var As String
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        q1var = "insert into Ccustentry("
        q2var = "values("
        q1var = q1var & "Caccno" & ","
        q2var = q2var & "'" & TextBox1.Text & "',"
        q1var = q1var & "Name" & ","
        q2var = q2var & "'" & TextBox2.Text & "',"
        q1var = q1var & "Address" & ","
        q2var = q2var & "'" & TextBox3.Text & "',"
        q1var = q1var & "Pincode" & ","
        q2var = q2var & "'" & TextBox4.Text & "',"
        q1var = q1var & "Gender" & ","
        q2var = q2var & "'" & ComboBox1.Text & "',"
        q1var = q1var & "Phoneno" & ","
        q2var = q2var & "'" & TextBox5.Text & "',"
        q1var = q1var & "email" & ","
        q2var = q2var & "'" & TextBox6.Text & "',"
        q1var = q1var & "Dob" & ")"
        q2var = q2var & "'" & DateTimePicker1.Text & "')"
        MsgBox(q1var & q2var)
        Dim cmd1 As New SqlCommand(q1var & q2var, conn)
        cmd1.ExecuteNonQuery()
        MsgBox("Data Saved")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
    End Sub
    Sub disrecord()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim ds1 As New DataSet
        Dim adp As New SqlDataAdapter("Select * from Ccustentry order by Caccno", conn)
        adp.Fill(ds1)
        DataGridView1.DataSource = ds1.Tables(0)
        If conn.State = ConnectionState.Open Then conn.Close()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If vbNo = MsgBox("Are you sure , you want to update this ?", MsgBoxStyle.YesNo, "Update") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from Ccustentry where Caccno='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        saverecord()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If vbNo = MsgBox("Are you sure , you want to delete this ?", MsgBoxStyle.YesNo, "Delete") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from Ccustentry where Caccno='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        ComboBox1.Text = ""
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        disrecord()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        pkvar = DataGridView1.CurrentRow.Cells(0).Value
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from Ccustentry where Caccno='" & pkvar & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            d1.Read()
            TextBox1.Text = d1(0).ToString
            TextBox2.Text = d1(1).ToString
            ComboBox1.Text = d1(2).ToString
            DateTimePicker1.Text = d1(3).ToString
            TextBox3.Text = d1(4).ToString
            TextBox4.Text = d1(5).ToString
            TextBox5.Text = d1(6).ToString
            TextBox6.Text = d1(7).ToString
        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            ComboBox1.Text = ""
        End If
    End Sub

    Private Sub Ccustform_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        disrecord()
        Me.WindowState = FormWindowState.Maximized
        a = RandGen.Next(101, 200).ToString
        TextBox1.Text = "CA25330" + a
    End Sub

    Private Sub TextBox5_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.LostFocus
        'Dim phoneNumber As New Regex("\d{3}\d{3}\d{4}")
        Dim phoneNumber As New Regex("^([6-9]{1})([0-9]{9})")
        TextBox5.MaxLength = 10

        If phoneNumber.IsMatch(TextBox5.Text) Then

            TextBox6.Focus()
        Else

            MsgBox("Not Valid Phone Number")
            TextBox5.Text = ""
            TextBox5.Focus()

        End If
    End Sub


    Private Sub TextBox6_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.LostFocus
        Dim regex As Regex = New Regex("^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
        Dim isValid As Boolean = regex.IsMatch(TextBox6.Text.Trim)
        If Not isValid Then
            MessageBox.Show("Invalid Email.")
        End If
    End Sub

    Private Sub TextBox2_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.LostFocus
        '  If Not Regex.Match(TextBox2.Text, "^[a-z. ]*$", RegexOptions.IgnoreCase).Success Then
        'MsgBox("please enter alpha text only!")
        'TextBox2.Focus()
        'TextBox2.Clear()

        'End If
    End Sub
 
    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        a = RandGen.Next(101, 200).ToString
        TextBox1.Text = "SB25330" + a
    End Sub
End Class