﻿Imports System.Data.SqlClient

Public Class Sbacctypeform

    Private Property pkvar As Object

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If vbNo = MsgBox("Are you sure , you want to update this ?", MsgBoxStyle.YesNo, "Update") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from Saavingsbankacctype where Sbacctype='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        saverecord()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        saverecord()
    End Sub
    Sub saverecord()
        If TextBox1.Text = "" Then
            MsgBox("Please enter the type of account")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("Please enter some facilities")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("Please enter min. balance")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("Please enter the remarks")
            Exit Sub
        End If
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from Saavingsbankacctype where Sbacctype='" & TextBox1.Text & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            MsgBox("Record is already present")
            Exit Sub
        End If
        Dim q1var, q2var As String
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        q1var = "insert into Saavingsbankacctype("
        q2var = "values("
        q1var = q1var & "Sbacctype" & ","
        q2var = q2var & "'" & TextBox1.Text & "',"
        q1var = q1var & "Facility" & ","
        q2var = q2var & "'" & TextBox2.Text & "',"
        q1var = q1var & "Minbalance" & ","
        q2var = q2var & "'" & TextBox3.Text & "',"
        q1var = q1var & "Remarks" & ")"
        q2var = q2var & "'" & TextBox4.Text & "')"
        MsgBox(q1var & q2var)
        Dim cmd1 As New SqlCommand(q1var & q2var, conn)
        cmd1.ExecuteNonQuery()
        MsgBox("Data Saved")
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
    End Sub
    Sub disrecord()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim ds1 As New DataSet
        Dim adp As New SqlDataAdapter("Select * from Saavingsbankacctype order by Sbacctype", conn)
        adp.Fill(ds1)
        DataGridView1.DataSource = ds1.Tables(0)
        If conn.State = ConnectionState.Open Then conn.Close()
    End Sub

    Private Sub Form2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        disrecord()
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        pkvar = DataGridView1.CurrentRow.Cells(0).Value
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd0 As New SqlCommand("select * from Saavingsbankacctype where Sbacctype='" & pkvar & "'", conn)
        Dim d1 As SqlDataReader = cmd0.ExecuteReader
        If d1.HasRows Then
            d1.Read()
            TextBox1.Text = d1(0).ToString
            TextBox2.Text = d1(1).ToString
            TextBox3.Text = d1(2).ToString
            TextBox4.Text = d1(3).ToString
        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
        End If
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If vbNo = MsgBox("Are you sure , you want to update this ?", MsgBoxStyle.YesNo, "Delete") Then Exit Sub
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        Dim cmd1 As New SqlCommand("Delete from Saavingsbankacctype where Sbacctype='" & pkvar & "'", conn)
        cmd1.ExecuteNonQuery()
        If conn.State = ConnectionState.Open Then conn.Close()
        conn.Open()
        disrecord()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        disrecord()
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs)

    End Sub
End Class